#include "xil_printf.h"
#include "xstatus.h"

#include "ap/StopWatch.h"
#include "common/delay/delay.h"
#include "common/interrupt/interrupt.h"
#include "HAL/TMR/TMR.h"
#include "HAL/I2C/I2C.h"
#include "driver/LCD_I2C/LCD_I2C.h"

int main(void)
{
    uint32_t prev_lcd_time = 0U;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint8_t centisecond;
    I2C_Status_t status;

    StopWatch_Init();
    I2C_Init(I2C0);
    LCD_I2C_Init(I2C0);

    /* 100 MHz / (100 * 1000) = 1 kHz -> 1 ms timer ISR */
    TMR_SetPSC(TMR0, 100U - 1U);
    TMR_SetARR(TMR0, 1000U - 1U);
    TMR_SetCNT(TMR0, 0U);

    if (SetupInterruptSystem() != XST_SUCCESS) {
        xil_printf("Interrupt setup failed\r\n");
        return -1;
    }

    /* First enable controller routing, then assert IP-level interrupt enable. */
    I2C_EnableInterrupt(I2C0);

    TMR_StartInterrupt(TMR0);
    TMR_StartTimer(TMR0);

    status = LCD_Init();
    if (status != I2C_OK) {
        xil_printf("LCD init failed: %d\r\n", (int)status);
    } else {
        (void)LCD_WriteLine(0U, "I2C LCD READY");
        (void)LCD_WriteLine(1U, "STOPWATCH INTR");
        delay_ms(800U);
    }

    while (1) {
        StopWatch_Execute();

        /* LCD transfer is intentionally foreground code, not ISR code. */
        if ((millis() - prev_lcd_time) >= 100U) {
            prev_lcd_time = millis();

            StopWatch_GetTime(&hour, &min, &sec, &centisecond);
            status = LCD_ShowStopWatch(hour,
                                       min,
                                       sec,
                                       centisecond,
                                       (StopWatch_GetState() == RUN) ? 1U : 0U);

            if (status != I2C_OK) {
                xil_printf("I2C LCD error=%d SR=0x%08lx irq=%lu\r\n",
                           (int)status,
                           (unsigned long)I2C0->SR,
                           (unsigned long)I2C_GetInterruptCount());
            }
        }
    }
}
