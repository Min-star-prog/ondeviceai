
#include "xil_printf.h"

#include "ap/StopWatch.h"
#include "common/delay/delay.h"
#include "common/interrupt/interrupt.h"
#include "HAL/TMR/TMR.h"
#include "HAL/UART/UART.h"
#include "driver/Button/Button.h"

int main()
{
	TMR_SetPSC(TMR0, 100-1);
	TMR_SetARR(TMR0, 1000-1);
	TMR_StartInterrupt(TMR0);
	TMR_StartTimer(TMR0);

	UART_StartInterrupt(UART0);

	StopWatch_Init();
	SetupInterruptSystem();

	uint32_t prevTime = 0;

	while(1)
	{
		StopWatch_Execute();

		if(Button_GetState(&hbtnLeft) == ACT_RELEASED){
				UART_Transmit(UART0, 'r');
		}
		if(Button_GetState(&hbtnRight) == ACT_RELEASED){
				UART_Transmit(UART0, 'c');
		}
//
//		delay_ms(200);
//
//		if(millis() - prevTime > 1000) {
//			prevTime = millis();
////			LED_PinOn(2);
//			LED_PinToggle(2);
//		}

		//*****************polling service routine***********
		//�� �Ʒ����� �׻� ���ƾ��ϴ� code��.}
//		FND_Execute();
//		incTick();
//		delay_ms(1);
	}
	return 0;
}

