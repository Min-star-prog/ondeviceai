///*
// * StopWatch.h
// *
// *  Created on: 2026. 6. 24.
// *      Author: kccistc
// */
//
//#ifndef SRC_AP_STOPWATCH_EX_H_
//#define SRC_AP_STOPWATCH_EX_H_
//
//#include "../driver/Button/Button.h"
//#include "../driver/FND/FND_ex.h"
//#include "../driver/LED/LED.h"
//
//typedef enum {
//	STOP = 0,
//	RUN,
//	CLEAR
//}StopWatch_e;
//
//void StopWatch_Init();
//void StopWatch_Execute();
//void StopWatch_ControlState();
//void StopWatch_RunTime();
//void StopWatch_UpdateDot();
//uint32_t StopWatch_GetFndNumber();
//
//void StopWatch_ClearLed();
//void StopWatch_StopLed();
//void StopWatch_RunLed();
//void StopWatch_ControlLed();
//
//#endif /* SRC_AP_STOPWATCH_EX_H_ */
