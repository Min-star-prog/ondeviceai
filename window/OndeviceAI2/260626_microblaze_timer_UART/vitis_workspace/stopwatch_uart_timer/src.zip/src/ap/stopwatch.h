/*
 * StopWatch.h
 *
 *  Created on: 2026. 6. 24.
 *      Author: kccistc
 */

#ifndef SRC_AP_STOPWATCH_H_
#define SRC_AP_STOPWATCH_H_

#include "../driver/Button/Button.h"
#include "../driver/FND/FND.h"
#include "../driver/LED/LED.h"

#define STOP_STATE_LED 	5
#define RUN_STATE_LED 	7

typedef enum {
	STOP = 0,
	RUN,
	CLEAR
}StopWatch_e;

void StopWatch_Init();
void StopWatch_Execute();
void StopWatch_ControlState();
void StopWatch_RunTime();
void StopWatch_DispWatch();

void StopWatch_ClearLed();
void StopWatch_StopLed();
void StopWatch_RunLed();
void StopWatch_ControlLed();

void StopWatch_ClearTime();
void StopWatch_IncTime();
#endif /* SRC_AP_STOPWATCH_H_ */
