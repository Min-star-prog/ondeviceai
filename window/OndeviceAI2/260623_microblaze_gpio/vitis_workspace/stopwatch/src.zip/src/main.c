
#include "xil_printf.h"
#include "common/delay/delay.h"
#include "ap/StopWatch.h"

int main()
{

	StopWatch_Init();
	while(1)
	{
		StopWatch_Execute();



//		curTime = millis();
//		if(curTime - prevTime >99) {
//			prevTime = curTime;
//		xil_printf("counter = %d\n", counter++);
//
//		//ledState = (ledState << 1) | (ledState >> 7);	//���� shift
//		ledState = (ledState >> 1) | (ledState << 15);	//������ shift
//		LED_WritePort16(ledState);
//
//		FND_SetNum(counter++);
//		}
		//*****************polling service routine***********
		//�� �Ʒ����� �׻� ���ƾ��ϴ� code��.}
		FND_Execute();
		incTick();
		delay_ms(1);
	}
	return 0;
}

