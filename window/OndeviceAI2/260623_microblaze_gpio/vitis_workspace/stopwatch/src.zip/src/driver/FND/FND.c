
#include "FND.h"

uint32_t fndNumber = 0;
static uint8_t fndDotMask = 0;
uint32_t dotOn = 0;

void FND_Init()
{
	uint32_t fndComTemp = GPIO_GetCR(GPIOB);
	fndComTemp |= 0x0f;
	GPIO_SetMode(GPIOB, fndComTemp);
	GPIO_SetMode(GPIOA, 0xff);
}
void FND_SetDotMask(uint8_t dotMask)
{
    fndDotMask = dotMask & 0x0f;
}


void FND_SetNum(uint32_t num)
{
	fndNumber =num;
}

void FND_Execute()
{
	FND_DispNum(fndNumber);
}
void FND_SelDigit(uint32_t digit)
{
	uint32_t digitPos;

	digitPos = GPIO_GetODR(FND_COM_GPIO);

	digitPos = (digitPos | 0x0f) & ~(1<<digit);	// ���� bit�� ����, ���� bit�� �մ�ڴ�.

	GPIO_WritePort(FND_COM_GPIO,  digitPos);
}



uint8_t FND_SetDot(uint8_t segData, uint8_t dotOn)
{
    if (dotOn) {
        // active-low: 0�̸� dot ON
        return (uint8_t)(segData & ~(1 << 7));
    } else {
        // active-low: 1�̸� dot OFF
        return (uint8_t)(segData | (1 << 7));
    }
}

void FND_DispDigit(uint32_t num,uint8_t dotOn)
{
	uint8_t fndFont[16] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8,
			0x80, 0x90, 0x88, 0x83, 0xc6, 0xa1, 0x86, 0x8e};

    uint8_t segData = fndFont[num % 10];

    segData = FND_SetDot(segData, dotOn);

    GPIO_WritePort(FND_DATA_GPIO, segData);
}

void FND_DispAllOff()
{
	uint32_t digitPos;

	digitPos = GPIO_GetODR(FND_COM_GPIO);
	digitPos = digitPos | 0x0f;	//-> 1�� �����

	GPIO_WritePort(FND_COM_GPIO,  digitPos);

}
void FND_DispNum(uint32_t num)
{
	static uint32_t fndDigitState = 0;
	fndDigitState = (fndDigitState + 1) % 4;

	FND_DispAllOff();//�ܻ��� ����

	switch (fndDigitState)
	  {
	    case 0:
	        // ������ ��: 0.1��
	        FND_DispDigit(num % 10,fndDotMask & (1 << FND_DIGIT_0));
	        FND_SelDigit(FND_DIGIT_0);
	        break;

	    case 1:
	        // �����ʿ��� �� ��°: �� 1�� �ڸ�
	        FND_DispDigit((num / 10) % 10,
	                      fndDotMask & (1 << FND_DIGIT_1));
	        FND_SelDigit(FND_DIGIT_1);
	        break;

	    case 2:
	        // �����ʿ��� �� ��°: �� 10�� �ڸ�
	        FND_DispDigit((num / 100) % 10,
	                      fndDotMask & (1 << FND_DIGIT_2));
	        FND_SelDigit(FND_DIGIT_2);
	        break;

	    case 3:
	        // ���� ��: �� 1�� �ڸ�
	        FND_DispDigit((num / 1000) % 10,
	                      fndDotMask & (1 << FND_DIGIT_3));
	        FND_SelDigit(FND_DIGIT_3);
	        break;
	    }
}





